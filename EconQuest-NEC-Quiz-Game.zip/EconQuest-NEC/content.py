"""Original educational content for the EconQuest National Economics Challenge study app."""

LESSONS = {
    'Microeconomics': [
        {'name':'Scarcity & opportunity cost', 'explanation':'Resources are limited, so every choice has a tradeoff. Opportunity cost is the value of the best alternative you give up.', 'formula':'Opportunity cost = value of next-best alternative', 'example':'Choosing an unpaid seminar over an $80 work shift has an opportunity cost of $80 if working is the next-best option.'},
        {'name':'Supply, demand & equilibrium', 'explanation':'Demand generally slopes downward and supply upward. Equilibrium is where quantity demanded equals quantity supplied. A change in the good’s own price causes movement along a curve; other determinants shift curves.', 'formula':'At equilibrium: Qd = Qs', 'example':'Higher manufacturing costs shift supply left, generally increasing market price and reducing equilibrium quantity.'},
        {'name':'Elasticity', 'explanation':'Price elasticity of demand measures how responsive quantity demanded is to a price change. Elastic demand has absolute elasticity greater than 1.', 'formula':'Ed = (% change in quantity demanded) / (% change in price)', 'example':'A 5% price increase that reduces quantity demanded by 15% gives Ed = −3 (elastic).'},
        {'name':'Markets and firms', 'explanation':'Profits equal revenue minus costs. A price-taking firm chooses output where marginal revenue equals marginal cost when production is worthwhile.', 'formula':'Profit = TR − TC; MC = ΔTC / ΔQ', 'example':'If revenue is $600 and economic costs are $450, economic profit is $150.'},
    ],
    'Macroeconomics': [
        {'name':'GDP and economic output', 'explanation':'Real GDP measures inflation-adjusted domestic output. The expenditure approach adds consumption, investment, government purchases, and net exports.', 'formula':'GDP = C + I + G + (X − M)', 'example':'C=500, I=100, G=200, X=80, M=60 means GDP=820.'},
        {'name':'Inflation & unemployment', 'explanation':'Inflation is an increase in the overall price level. Unemployment rate counts unemployed jobseekers as a share of the labor force, not the whole population.', 'formula':'Inflation = (CPI_new − CPI_old) / CPI_old × 100%; Unemployment = Unemployed / Labor Force × 100%', 'example':'CPI moving from 200 to 210 indicates 5% inflation.'},
        {'name':'Aggregate demand (AD)', 'explanation':'AD gives real GDP demanded at each overall price level. It slopes downward. Changes in consumption, investment, government purchases, or net exports that are not caused by the price level can shift AD.', 'formula':'AD components: C + I + G + (X − M)', 'example':'An increase in government highway spending shifts AD right, increasing short-run equilibrium price level and output if SRAS is unchanged.'},
        {'name':'Short-run aggregate supply (SRAS)', 'explanation':'SRAS shows real output supplied at each price level in the short run. Higher production costs shift SRAS left; improvements in productivity can shift it right.', 'formula':'AD right → P↑, Y↑; SRAS left → P↑, Y↓', 'example':'A higher oil price can shift SRAS left, increasing the price level while decreasing real GDP.'},
        {'name':'Long-run aggregate supply (LRAS)', 'explanation':'LRAS is vertical at potential real GDP in the basic model. Improvements in technology, workforce, human capital, or physical capital shift it right.', 'formula':'LRAS = potential real GDP (vertical curve)', 'example':'A sustained productivity improvement can expand potential output.'},
        {'name':'Fiscal and monetary policy', 'explanation':'Fiscal policy changes government taxes and purchases. Monetary policy uses central-bank tools to influence financial conditions and aggregate demand.', 'formula':'Spending multiplier (simple model) = 1 / (1 − MPC)', 'example':'An interest-rate increase generally slows interest-sensitive spending, shifting AD left relative to otherwise.'},
    ],
    'International Economics': [
        {'name':'Comparative advantage', 'explanation':'Comparative advantage depends on lower opportunity cost, not simply which country can produce more of everything.', 'formula':'Opportunity cost of A = units of B forgone / units of A gained', 'example':'If A gives up two computers per car and B gives up three, A has comparative advantage in cars.'},
        {'name':'Trade restrictions', 'explanation':'Tariffs tax imports; quotas limit quantities. In a standard small-country model, tariffs raise domestic prices, reduce imports, and produce deadweight loss.', 'formula':'Trade balance = exports − imports', 'example':'A tariff on imported steel may benefit domestic steel producers but raise costs for buyers of steel.'},
        {'name':'Exchange rates', 'explanation':'A currency appreciation makes that currency more valuable relative to another; domestically priced exports usually become more expensive to foreign buyers, all else equal.', 'formula':'Exchange rate = price of one currency in another', 'example':'If the U.S. dollar appreciates relative to the euro, euro-priced imports become cheaper in dollar terms.'},
    ],
}

# Original practice questions, not reproduced from copyrighted NEC exam booklets.
QUESTIONS = [
 ('Microeconomics','Which is the best definition of opportunity cost?', ['All money spent','The next-best alternative forgone','The total of every alternative','A fixed production cost'],1,'Opportunity cost is the value of the single next-best alternative forgone.'),
 ('Microeconomics','If demand increases and supply stays constant, what usually happens?', ['Price and quantity both rise','Price falls and quantity rises','Both fall','Price rises and quantity falls'],0,'A rightward demand shift raises both equilibrium price and quantity.'),
 ('Microeconomics','Price rises 10% and quantity demanded falls 20%. Absolute price elasticity is:', ['0.5','1','2','10'],2,'20/10 = 2, so demand is elastic.'),
 ('Microeconomics','A binding price ceiling below equilibrium typically produces a:', ['Surplus','Shortage','Supply increase','No change'],1,'At the lower price, quantity demanded exceeds quantity supplied.'),
 ('Microeconomics','A competitive firm has MR=$12 and MC=$9 for an additional unit. Assuming standard conditions, it should:', ['Reduce output','Increase output','Shut down automatically','Ignore marginal costs'],1,'The additional unit increases profit because MR exceeds MC.'),
 ('Microeconomics','A company has total revenue of $900 and total economic cost of $750. Economic profit is:', ['$150','$750','$900','$1,650'],0,'900 − 750 = 150.'),
 ('Macroeconomics','C=500, I=120, G=180, exports=50, imports=70. GDP equals:', ['780','800','820','920'],0,'500+120+180+50−70 = 780.'),
 ('Macroeconomics','CPI moves from 240 to 252. Inflation is:', ['4%','5%','12%','20%'],1,'12/240 = 0.05 = 5%.'),
 ('Macroeconomics','When aggregate demand shifts right while SRAS stays fixed, short-run equilibrium generally shows:', ['Higher P and higher Y','Lower P and higher Y','Higher P and lower Y','Lower P and lower Y'],0,'AD shifts right: both the price level and real GDP increase.'),
 ('Macroeconomics','A large increase in oil input costs generally shifts:', ['AD right','AD left','SRAS right','SRAS left'],3,'Higher production costs reduce output supplied at each price level.'),
 ('Macroeconomics','In the basic AD–AS model, LRAS is drawn:', ['Downward sloping','Horizontal at zero','Vertical at potential GDP','Upward sloping like SRAS'],2,'Potential output is determined by productive capacity in the long run.'),
 ('Macroeconomics','Which is an expansionary fiscal policy?', ['Higher income taxes','Lower government purchases','Higher government purchases','Higher policy interest rates'],2,'Higher government purchases increase aggregate demand, all else equal.'),
 ('Macroeconomics','There are 6 million unemployed and 114 million employed people. The unemployment rate is:', ['5%','5.26%','6%','20%'],0,'Labor force=120 million; 6/120=5%.'),
 ('Macroeconomics','If real GDP is below potential GDP, the economy has:', ['An inflationary gap','A recessionary gap','No gap','A currency appreciation'],1,'Real output below potential is a recessionary gap.'),
 ('International Economics','Country A gives up 2 shirts per computer; B gives up 5. Who has comparative advantage in computers?', ['A','B','Both equally','Neither'],0,'A has the lower opportunity cost.'),
 ('International Economics','If the dollar appreciates against the euro, euro-priced imported goods generally become:', ['More expensive in dollars','Cheaper in dollars','Unaffected in all cases','Illegal to import'],1,'A stronger dollar buys more euros.'),
 ('International Economics','In a standard small-country trade model, an import tariff typically:', ['Lowers domestic prices','Increases imports','Creates deadweight loss','Eliminates domestic production'],2,'Tariffs distort consumption and production and create efficiency losses.'),
 ('International Economics','Exports of $400 and imports of $550 imply:', ['$150 trade surplus','$150 trade deficit','$950 trade deficit','Balanced trade'],1,'400−550=−150, a trade deficit.'),
]

def validate_question_bank():
    for category, question, choices, answer, explanation in QUESTIONS:
        assert category in LESSONS
        assert len(choices) == 4 and len(set(choices)) == 4
        assert 0 <= answer < 4
        assert question.strip() and explanation.strip()
    return True
