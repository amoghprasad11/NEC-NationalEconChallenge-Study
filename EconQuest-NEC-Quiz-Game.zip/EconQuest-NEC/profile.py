"""Portable JSON profiles for reproducible progress; no server-side personal accounts."""
import json
from copy import deepcopy

VOCAB = {
    'Opportunity cost':'Value of the next-best alternative forgone.',
    'Scarcity':'Limited resources compared with unlimited wants.',
    'Demand shift':'A movement of the whole demand curve due to a non-price determinant.',
    'Market equilibrium':'Where quantity supplied equals quantity demanded.',
    'Price elasticity of demand':'Percent change in quantity demanded divided by percent change in price.',
    'Price ceiling':'A legal maximum price; when binding, creates a shortage.',
    'Shortage':'Quantity demanded exceeds quantity supplied at the current price.',
    'Marginal revenue':'Additional revenue earned from selling one more unit.',
    'Marginal cost':'Additional cost of producing one more unit.',
    'Economic profit':'Total revenue minus explicit and implicit economic costs.',
    'Gross Domestic Product':'Market value of final goods and services produced domestically in a period.',
    'Net exports':'Exports minus imports.',
    'Consumer Price Index':'Price index tracking a representative consumer basket.',
    'Inflation':'Rise in the overall price level over time.',
    'Aggregate demand':'Total real GDP demanded at each overall price level.',
    'Short-run aggregate supply':'Total real GDP supplied at different price levels in the short run.',
    'Supply shock':'Unexpected change in production costs or supply conditions.',
    'Long-run aggregate supply':'Vertical curve at the economy’s potential real output.',
    'Potential GDP':'Sustainable output at normal resource utilization.',
    'Fiscal policy':'Government tax and spending decisions that influence the economy.',
    'Unemployment rate':'Unemployed actively seeking work divided by labor force.',
    'Labor force':'Employed plus unemployed people who meet the labor-force definition.',
    'Recessionary gap':'Real GDP below potential GDP.',
    'Comparative advantage':'Ability to produce at lower opportunity cost.',
    'Currency appreciation':'A currency gaining value relative to another currency.',
    'Exchange rate':'Price of one currency in terms of another.',
    'Tariff':'Tax on imported goods.',
    'Deadweight loss':'Lost gains from trade because of an inefficient distortion.',
    'Trade balance':'Exports minus imports.',
    'Trade deficit':'Imports exceed exports.',
}

def new_profile():
    return {'version':1,'history':{},'lists':{'Missed concepts':[]},'lessons':[],
            'attempts':[], 'xp':0, 'definitions':{}}

def validate_profile(data):
    if not isinstance(data,dict) or data.get('version')!=1:
        raise ValueError('Not an EconQuest version 1 profile.')
    result=new_profile()
    for field in ('history','lists','definitions'):
        v=data.get(field,{})
        if not isinstance(v,dict) or len(v)>5000:
            raise ValueError('Invalid profile mapping.')
        result[field]=deepcopy(v)
    for field in ('lessons','attempts'):
        v=data.get(field,[])
        if not isinstance(v,list) or len(v)>10000:
            raise ValueError('Invalid profile list.')
        result[field]=deepcopy(v)
    result['xp']=max(0,int(data.get('xp',0)))
    if not all(isinstance(k,str) and isinstance(v,list) and all(isinstance(t,str) for t in v)
               for k,v in result['lists'].items()):
        raise ValueError('Malformed vocabulary lists.')
    if not isinstance(result['history'],dict):
        raise ValueError('Malformed history.')
    return result

def to_json(profile):
    return json.dumps(validate_profile(profile),indent=2,ensure_ascii=False)

def add_vocab(profile, term, list_name='Missed concepts'):
    lists=profile.setdefault('lists',{})
    words=lists.setdefault(list_name,[])
    if term not in words:
        words.append(term)
