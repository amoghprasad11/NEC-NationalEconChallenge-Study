"""Deterministic question generation, spaced-review weighting, and scoring."""
from __future__ import annotations
import random
from collections import Counter
from content import QUESTIONS

TOPICS = {
    'Microeconomics': ['Opportunity cost', 'Supply and demand', 'Elasticity', 'Firms and costs'],
    'Macroeconomics': ['GDP', 'Inflation and unemployment', 'Aggregate demand and supply', 'Fiscal and monetary policy'],
    'International Economics': ['Comparative advantage', 'Exchange rates', 'Trade policy'],
}

# New question templates produce reproducible, numerical variants and worked explanations.
def generated_questions(seed: int = 1):
    rng = random.Random(seed)
    questions = []
    def add(id_, category, topic, prompt, choices, answer, explanation, terms, visual='none'):
        questions.append({'id': id_, 'category': category, 'topic': topic, 'prompt': prompt,
                          'choices': choices, 'answer': answer, 'explanation': explanation,
                          'terms': terms, 'visual': visual, 'source': 'Original • generated'})
    for n in range(12):
        old = rng.randrange(120, 350, 10)
        rise = rng.choice([5, 10, 15, 20])
        new = old * (100 + rise) / 100
        add(f'generated-inflation-{n}', 'Macroeconomics','Inflation and unemployment',
            f'A country’s CPI rose from {old} to {new:g}. What was the inflation rate?',
            [f'{x}%' for x in [rise/2, rise, rise+3, rise*2]], 1,
            f'Inflation = (new CPI − old CPI) / old CPI × 100 = ({new:g} − {old}) / {old} × 100 = {rise}%.',
            ['Consumer Price Index', 'Inflation'])
        c, i, g, ex, im = [rng.randrange(50, 550, 10) for _ in range(5)]
        result = c+i+g+ex-im
        add(f'generated-gdp-{n}', 'Macroeconomics','GDP',
            f'If C={c}, I={i}, G={g}, exports={ex}, and imports={im} (all in billions), what is GDP?',
            [str(result+im),str(result-50),str(result),str(result+50)], 2,
            f'GDP = C + I + G + (exports − imports) = {c}+{i}+{g}+({ex}−{im}) = {result} billion.',
            ['Gross Domestic Product','Net exports'], 'gdp')
        price_change = rng.choice([5,10,20,25])
        ratio = rng.choice([0.5,1.5,2,3])
        qty_change = price_change * ratio
        answer = 1 if ratio>1 else 0
        add(f'generated-elasticity-{n}', 'Microeconomics','Elasticity',
            f'Price increases {price_change}% and quantity demanded falls {qty_change:g}%. Is demand elastic or inelastic?',
            ['Inelastic','Elastic','Perfectly inelastic','Cannot determine'], answer,
            f'Absolute elasticity = {qty_change:g} / {price_change} = {ratio:g}. A value greater than 1 is elastic; below 1 is inelastic.',
            ['Price elasticity of demand'])
        unemployed = rng.choice([4,6,8,10,12])
        employed = rng.choice([90,110,130,150])
        rate = 100*unemployed/(employed+unemployed)
        opts = [f'{v:.2f}%' for v in [100*unemployed/employed, rate, rate+2, rate/2]]
        add(f'generated-unemployment-{n}', 'Macroeconomics','Inflation and unemployment',
            f'There are {unemployed} million unemployed and {employed} million employed people. What is the unemployment rate? (Round to 2 decimals.)',
            opts, 1,
            f'Labor force = {unemployed}+{employed}={unemployed+employed} million. Rate = {unemployed}/{unemployed+employed}×100 = {rate:.2f}%.',
            ['Labor force','Unemployment rate'])
    return questions


def all_questions(seed: int = 1):
    legacy = []
    topic_by_index = [
        'Opportunity cost','Supply and demand','Elasticity','Supply and demand',
        'Firms and costs','Firms and costs','GDP','Inflation and unemployment',
        'Aggregate demand and supply','Aggregate demand and supply',
        'Aggregate demand and supply','Fiscal and monetary policy',
        'Inflation and unemployment','Aggregate demand and supply',
        'Comparative advantage','Exchange rates','Trade policy','Trade policy'
    ]
    terms = [
        ['Opportunity cost','Scarcity'],['Demand shift','Market equilibrium'],['Price elasticity of demand'],
        ['Price ceiling','Shortage'],['Marginal revenue','Marginal cost'],['Economic profit'],
        ['Gross Domestic Product','Net exports'],['Consumer Price Index','Inflation'],
        ['Aggregate demand','Short-run aggregate supply'],['Short-run aggregate supply','Supply shock'],
        ['Long-run aggregate supply','Potential GDP'],['Fiscal policy'],
        ['Unemployment rate','Labor force'],['Recessionary gap','Potential GDP'],
        ['Comparative advantage','Opportunity cost'],['Currency appreciation','Exchange rate'],
        ['Tariff','Deadweight loss'],['Trade balance','Trade deficit']
    ]
    for i,(category,prompt,choices,answer,explanation) in enumerate(QUESTIONS):
        visual = ('adas' if i in (8,9,10,13) else 'market' if i in (1,3) else 'gdp' if i==6 else 'none')
        legacy.append({'id':f'core-{i+1}', 'category':category,'topic':topic_by_index[i],
                        'prompt':prompt, 'choices':choices,'answer':answer,
                        'explanation':explanation,'terms':terms[i], 'visual':visual,
                        'source':'Original • hand-written'})
    return legacy + generated_questions(seed)


def choose_questions(pool, count, mode='Mixed practice', history=None, seed=1, category='All subjects'):
    history = history or {}
    filtered = [q for q in pool if category=='All subjects' or q['category']==category]
    if mode=='Review missed':
        filtered=[q for q in filtered if history.get(q['id'],{}).get('wrong',0)>0]
    if not filtered:
        return []
    rng=random.Random(seed)
    if mode == 'Adaptive learning':
        # Weighted sampling without replacement: missed questions and weak topics recur more often.
        topical=Counter()
        for q in filtered:
            record=history.get(q['id'],{})
            topical[q['topic']]+=max(0,record.get('wrong',0)-record.get('right',0))
        weights={q['id']:1+3*history.get(q['id'],{}).get('wrong',0)+topical[q['topic']] for q in filtered}
        selected=[]
        options=filtered.copy()
        while options and len(selected)<count:
            q=rng.choices(options,weights=[weights[o['id']] for o in options],k=1)[0]
            selected.append(q)
            options.remove(q)
        return selected
    return rng.sample(filtered,min(count,len(filtered)))


def record_answer(history, question, picked):
    """Return a new history mapping; no mutations to caller input."""
    history={k:dict(v) for k,v in history.items()}
    record=history.setdefault(question['id'],{'right':0,'wrong':0})
    is_correct=(picked==question['answer'])
    record['right' if is_correct else 'wrong']+=1
    return history,is_correct
