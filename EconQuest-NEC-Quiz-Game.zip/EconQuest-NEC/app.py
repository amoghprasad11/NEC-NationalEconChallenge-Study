"""EconQuest: quiz-first economics learning game for NEC David Ricardo practice."""
from __future__ import annotations
import json
import random
import streamlit as st
import pandas as pd
from content import LESSONS
from economics import equilibrium, directional_summary
from quiz_engine import TOPICS, all_questions, choose_questions, record_answer
from profile import VOCAB, add_vocab, new_profile, to_json, validate_profile
from visuals import adas_figure, market_figure, gdp_figure

st.set_page_config(page_title='EconQuest | Play. Learn. Review.',page_icon='🧠',layout='wide')
st.markdown('''<style>
.block-container{max-width:1200px;padding-top:1.35rem}
.hero{padding:22px 27px;border-radius:18px;background:linear-gradient(110deg,#12263f,#146477);color:#fff;margin:0 0 20px}
.hero h1,.hero p{color:#fff!important;margin:0}.hero p{opacity:.9;margin-top:8px}
[data-testid="stMetric"]{background:rgba(100,130,160,.08);border:1px solid rgba(100,130,160,.18);border-radius:13px;padding:13px}
.topic{font-size:.84rem;letter-spacing:.09em;color:#5daeb2;font-weight:700}
</style>''',unsafe_allow_html=True)

if 'profile' not in st.session_state:
    st.session_state.profile=new_profile()
if 'run' not in st.session_state:
    st.session_state.run=None
if 'current_choice' not in st.session_state:
    st.session_state.current_choice=None
if 'revealed' not in st.session_state:
    st.session_state.revealed=False

profile=st.session_state.profile
bank=all_questions(seed=7)

st.markdown('<div class="hero"><h1>🧠 EconQuest</h1><p>Play economics. Learn from every answer. Review the concepts you miss.</p></div>',unsafe_allow_html=True)
page=st.sidebar.radio('Choose your adventure',['🏠 Dashboard','🎯 Quiz Arena','📈 Graph Lab','📚 Vocabulary Vault','📖 Quick Lessons','📊 Progress & Profile','🔗 Official NEC Practice'])
st.sidebar.caption('Original questions • David Ricardo fundamentals • Independent educational project')
st.sidebar.metric('Your XP',f'{profile["xp"]:,}')


def glossary_add(terms, list_name='Missed concepts'):
    for term in terms:
        add_vocab(profile,term,list_name)


def show_question_visual(q):
    typ=q.get('visual','none')
    if typ=='adas':
        st.plotly_chart(adas_figure(),use_container_width=True,key=f'question_visual_{q["id"]}')
        st.caption('Reference diagram: AD slopes downward and SRAS slopes upward. Shift the relevant curve mentally before selecting.')
    elif typ=='market':
        st.plotly_chart(market_figure(),use_container_width=True,key=f'question_visual_{q["id"]}')
        st.caption('Reference diagram: a representative supply-and-demand market.')
    elif typ=='gdp':
        st.table({'GDP component':['Consumption','Investment','Government purchases','Net exports'],
                  'Symbol':['C','I','G','X − M']})


def start_quiz(mode,category,length,seed):
    pool=all_questions(seed=seed)
    selected=choose_questions(pool,length,mode,profile['history'],seed,category)
    if not selected:
        st.warning('No missed questions found yet. Play a regular round first, or choose Adaptive learning.')
        return
    st.session_state.run={'questions':selected,'i':0,'correct':0,'mode':mode,'category':category,'seed':seed,'finished':False}
    st.session_state.current_choice=None
    st.session_state.revealed=False
    st.rerun()


def quiz_arena():
    st.subheader('🎯 Quiz Arena')
    run=st.session_state.run
    if run is None:
        st.write('Answer one question at a time. After each answer, see the explanation and save key vocabulary automatically when you miss it.')
        col1,col2=st.columns(2)
        with col1:
            mode=st.selectbox('Game mode',['Adaptive learning','Mixed practice','Review missed'])
            category=st.selectbox('Question category',['All subjects',*TOPICS.keys()])
        with col2:
            length=st.slider('Questions per round',5,25,10,5)
            seed=st.number_input('Question set seed',min_value=1,max_value=999999,value=7)
        st.info('**Adaptive:** prioritizes missed questions and weak topics. **Review missed:** specifically revisits mistakes. **Mixed:** random practice. Questions may repeat to reinforce learning.')
        if st.button('🚀 Start round',type='primary',use_container_width=True):
            start_quiz(mode,category,length,int(seed))
        st.caption(f'{len(bank)} available questions (18 hand-written + 48 generated variants). Generated numbers are deterministic for a given seed.')
        return
    if run['finished']:
        total=len(run['questions'])
        pct=run['correct']/total if total else 0
        st.success(f'Round complete: {run["correct"]}/{total} correct ({pct:.0%})')
        st.metric('Total XP',profile['xp'])
        st.write('**What next?** Missed concepts were automatically added to your Vocabulary Vault. Review them, then play another adaptive round.')
        left,right=st.columns(2)
        if left.button('Play another round',type='primary',use_container_width=True):
            st.session_state.run=None
            st.rerun()
        if right.button('Review missed questions',use_container_width=True):
            st.session_state.run=None
            start_quiz('Review missed','All subjects',10,run['seed'])
        return
    idx=run['i']; q=run['questions'][idx]
    st.progress(idx/len(run['questions']))
    st.caption(f'QUESTION {idx+1} OF {len(run["questions"])} • {q["category"]} / {q["topic"]} • {q["source"]}')
    st.markdown(f'### {q["prompt"]}')
    if q.get('visual')!='none':
        with st.expander('📊 Open question graph / reference table',expanded=True):
            show_question_visual(q)
    options=list(range(4))
    # Unique widget ID per question occurrence prevents a previous answer carrying over.
    choice=st.radio('Choose one answer',options,format_func=lambda v:f'{chr(65+v)}. {q["choices"][v]}',
                    index=None,key=f'answer_{run["seed"]}_{idx}_{q["id"]}',disabled=st.session_state.revealed)
    if not st.session_state.revealed:
        if st.button('Check answer',type='primary',disabled=choice is None,use_container_width=True):
            st.session_state.current_choice=choice
            st.session_state.revealed=True
            history,correct=record_answer(profile['history'],q,choice)
            profile['history']=history
            profile['xp']+=10 if correct else 2
            if correct:
                run['correct']+=1
            else:
                glossary_add(q['terms'])
            st.rerun()
    else:
        correct=st.session_state.current_choice==q['answer']
        if correct: st.success('✅ Correct! +10 XP')
        else: st.error(f'Not quite. Correct answer: **{chr(65+q["answer"])}. {q["choices"][q["answer"]]}**  • +2 XP')
        st.info(f'**Why:** {q["explanation"]}')
        st.write('**Vocabulary from this question:**')
        st.table({'Term':q['terms'],'Explanation':[profile['definitions'].get(t,VOCAB.get(t,'See your course notes.')) for t in q['terms']]})
        existing=list(profile['lists'])
        target=st.selectbox('Save related words to a list',existing,key=f'save_list_{idx}')
        if st.button('➕ Save all these words',key=f'addwords_{idx}'):
            glossary_add(q['terms'],target)
            st.success(f'Saved to {target}.')
        if st.button('➡️ Next question' if idx+1<len(run['questions']) else '🏁 Finish round',type='primary',use_container_width=True):
            run['i']+=1
            st.session_state.revealed=False
            st.session_state.current_choice=None
            if run['i']>=len(run['questions']):
                run['finished']=True
                profile['attempts'].append({'mode':run['mode'],'category':run['category'],
                                            'score':run['correct'],'total':len(run['questions'])})
            st.rerun()


def graph_lab():
    st.subheader('📈 Interactive Economics Graph Lab')
    kind=st.selectbox('Choose a graph',['Aggregate demand & short-run supply','Market supply & demand','GDP expenditure table and chart'])
    if kind.startswith('Aggregate'):
        a,b=st.columns(2)
        with a: ad=st.slider('Move aggregate demand',-40,40,0,step=10)
        with b: sras=st.slider('Move short-run supply',-40,40,0,step=10)
        st.plotly_chart(adas_figure(ad,sras),use_container_width=True)
        start,end=equilibrium(),equilibrium(ad,sras)
        c,d=st.columns(2)
        c.metric('Equilibrium real GDP',f'{end.output:.1f}',f'{end.output-start.output:+.1f}')
        d.metric('Equilibrium price level',f'{end.price_level:.1f}',f'{end.price_level-start.price_level:+.1f}')
        st.info(directional_summary(ad,sras))
        st.caption('Illustrative teaching equations, not real U.S. economic forecasts. Change one slider at a time to isolate each effect.')
        with st.expander('What about LRAS?'):
            st.write('Long-run aggregate supply is vertical at potential real GDP. Sustained improvements in productivity, capital, and labor capacity shift LRAS right. This simulator focuses on short-run AD–SRAS equilibrium.')
    elif kind.startswith('Market'):
        a,b=st.columns(2)
        with a: demand=st.slider('Demand shift',-30,30,0,step=10)
        with b: supply=st.slider('Supply shift',-30,30,0,step=10)
        st.plotly_chart(market_figure(demand,supply),use_container_width=True)
        q=(90+demand+supply)/2
        p=100-q+demand
        st.table({'Variable':['Equilibrium quantity','Equilibrium price'], 'Illustrative result':[round(q,1),round(p,1)]})
        st.caption('Linear illustrative curves: demand P=100−Q+demand shift; supply P=10+Q−supply shift.')
    else:
        a,b,c=st.columns(3)
        cval=a.number_input('Consumption (C)',min_value=0,value=500)
        ival=b.number_input('Investment (I)',min_value=0,value=120)
        gval=c.number_input('Government purchases (G)',min_value=0,value=180)
        x= a.number_input('Exports (X)',min_value=0,value=50)
        m= b.number_input('Imports (M)',min_value=0,value=70)
        total=cval+ival+gval+x-m
        st.metric('GDP = C + I + G + (X − M)',f'{total:,}')
        st.plotly_chart(gdp_figure(cval,ival,gval,x,m),use_container_width=True)
        st.dataframe(pd.DataFrame([{'Component':'Consumption','Value':cval},{'Component':'Investment','Value':ival},
                                   {'Component':'Government','Value':gval},{'Component':'Exports','Value':x},
                                   {'Component':'Imports (subtracted)','Value':-m}]),hide_index=True)


def vocabulary_vault():
    st.subheader('📚 Vocabulary Vault')
    st.write('Missed questions automatically add their key concepts to **Missed concepts**. Create your own lists, edit definitions, and review them as flashcards.')
    with st.form('make_list',clear_on_submit=True):
        name=st.text_input('New vocabulary list name',max_chars=60)
        if st.form_submit_button('Create list') and name.strip():
            profile['lists'].setdefault(name.strip(),[])
            st.success('List created.')
    if not profile['lists']:
        profile['lists']['Missed concepts']=[]
    selected=st.selectbox('Select vocabulary list',list(profile['lists']))
    words=profile['lists'][selected]
    st.caption(f'{len(words)} saved terms in this list')
    available=sorted(set(VOCAB)|set(profile['definitions']))
    term=st.selectbox('Add a term from the glossary',available)
    if st.button('Add selected term'):
        add_vocab(profile,term,selected)
        st.rerun()
    with st.form('custom_term',clear_on_submit=True):
        custom=st.text_input('Or write your own term',max_chars=100)
        definition=st.text_area('Your definition',max_chars=600)
        if st.form_submit_button('Save custom term') and custom.strip() and definition.strip():
            term_name=custom.strip()
            profile['definitions'][term_name]=definition.strip()
            add_vocab(profile,term_name,selected)
            st.rerun()
    if not words:
        st.info('This list is empty. Miss a quiz question or add a term above to begin.')
        return
    mode=st.radio('Study method',['Flip flashcards','Vocabulary table'],horizontal=True)
    if mode=='Flip flashcards':
        n=st.slider('Flashcard number',1,len(words),1)
        word=words[n-1]
        st.markdown(f'### {word}')
        if st.toggle('Reveal definition',key=f'reveal_vocab_{selected}_{n}'):
            st.success(profile['definitions'].get(word,VOCAB.get(word,'Add a definition below.')))
    else:
        st.dataframe(pd.DataFrame([{'Term':w,'Definition':profile['definitions'].get(w,VOCAB.get(w,''))} for w in words]),hide_index=True,use_container_width=True)
    removal=st.selectbox('Remove a word from this list',words)
    if st.button('Remove selected word'):
        words.remove(removal)
        st.rerun()


def lessons_page():
    st.subheader('📖 Quick Lessons')
    st.write('The game is the main activity; lessons provide a quick refresher when a concept is unfamiliar.')
    category=st.selectbox('Category',list(LESSONS))
    name=st.selectbox('Lesson',[x['name'] for x in LESSONS[category]])
    lesson=next(x for x in LESSONS[category] if x['name']==name)
    st.markdown(f'### {name}')
    st.write(lesson['explanation'])
    st.info('**Core formula / rule:** '+lesson['formula'])
    st.success('**Worked example:** '+lesson['example'])
    if 'Aggregate demand' in name or 'aggregate supply' in name:
        st.plotly_chart(adas_figure(),use_container_width=True)
    lesson_id=f'{category}::{name}'
    if st.button('Mark lesson complete'):
        if lesson_id not in profile['lessons']:
            profile['lessons'].append(lesson_id)
            profile['xp']+=5
        st.success('Lesson completed!')


def progress_page():
    st.subheader('📊 Progress & Profile')
    st.write('Save a portable profile file to keep your quiz history and vocabulary lists. Upload it when you return or move to another device.')
    total_right=sum(v.get('right',0) for v in profile['history'].values())
    total_wrong=sum(v.get('wrong',0) for v in profile['history'].values())
    c1,c2,c3=st.columns(3)
    c1.metric('Lifetime accuracy',f'{total_right/max(1,total_right+total_wrong):.0%}')
    c2.metric('Questions answered',total_right+total_wrong)
    c3.metric('Words saved',sum(len(v) for v in profile['lists'].values()))
    st.subheader('Weak concepts')
    question_lookup={q['id']:q for q in bank}
    rows=[]
    for qid,record in profile['history'].items():
        q=question_lookup.get(qid)
        if q:
            rows.append({'Topic':q['topic'],'Correct':record.get('right',0),'Missed':record.get('wrong',0),'Question ID':qid})
    if rows:
        df=pd.DataFrame(rows)
        report=df.groupby('Topic',as_index=False)[['Correct','Missed']].sum()
        report['Accuracy']=report['Correct']/(report['Correct']+report['Missed'])
        st.dataframe(report.sort_values('Accuracy'),hide_index=True,use_container_width=True)
        st.bar_chart(report.set_index('Topic')[['Correct','Missed']])
    else:
        st.info('Complete a quiz round to see your topic-by-topic results.')
    if profile['attempts']:
        st.subheader('Quiz history')
        st.dataframe(pd.DataFrame(profile['attempts']),hide_index=True)
    st.divider()
    st.subheader('Keep your progress across sessions')
    st.download_button('⬇️ Download my learning profile (.json)',data=to_json(profile),
                       file_name='econquest-profile.json',mime='application/json',use_container_width=True)
    uploaded=st.file_uploader('Import a previously saved learning profile',type=['json'])
    if uploaded is not None and st.button('Import profile (replaces current session progress)'):
        try:
            if uploaded.size>2_000_000: raise ValueError('File is too large.')
            data=json.loads(uploaded.getvalue().decode('utf-8'))
            st.session_state.profile=validate_profile(data)
            st.session_state.run=None
            st.success('Profile imported successfully.')
            st.rerun()
        except (ValueError,UnicodeDecodeError,TypeError,OverflowError) as exc:
            st.error(f'Could not load profile: {exc}')
    st.caption('No login or cloud account is required. Session progress is not automatically permanent; download your profile before leaving. Do not import profiles from untrusted sources.')


def home():
    st.subheader('Ready for your next economics challenge?')
    a,b,c=st.columns(3)
    a.metric('Original question variants',len(bank))
    b.metric('XP earned',profile['xp'])
    c.metric('Saved vocabulary',sum(len(w) for w in profile['lists'].values()))
    st.write('**1. Play:** Answer questions and get explanations immediately.  **2. Explore:** Move AD–AS curves and edit GDP tables. **3. Remember:** Save the terms you miss, then quiz yourself again.')
    st.info('For the quickest improvement, start with **Adaptive learning**. It revisits weaker areas more often as you answer questions.')
    if st.button('Start a 10-question adaptive round',type='primary',use_container_width=True):
        start_quiz('Adaptive learning','All subjects',10,7)
    st.markdown('### What makes EconQuest different?')
    st.write('Every answer includes a reason, not just a grade. Numerical problems generate new values from reusable templates. Difficult concepts are collected into personal vocabulary lists you can export and return to later.')
    st.caption('Independent educational project. Not affiliated with or endorsed by the Council for Economic Education.')


def official():
    st.subheader('🔗 Official practice exam resources')
    st.write('Use these sources for **actual published NEC sample questions**. EconQuest does not reproduce copyrighted exam text or claim its original questions were used in past competitions.')
    st.markdown('- [Official NEC David Ricardo practice quiz](https://econchallenge.unl.edu/Nebraska/Practice) — questions from the official practice platform.')
    st.markdown('- [Council for Economic Education competitions](https://www.councilforeconed.org/competitions/) — competition and preparation information.')
    st.markdown('- [Economics Challenge preparation resources](https://www.econed.org/economics-challenge/) — sample tests, practice material and other resources.')
    st.write('When you miss a question on an official practice test, manually add its **economic concept** to the Vocabulary Vault and study that definition in EconQuest.')

if page=='🏠 Dashboard':home()
elif page=='🎯 Quiz Arena':quiz_arena()
elif page=='📈 Graph Lab':graph_lab()
elif page=='📚 Vocabulary Vault':vocabulary_vault()
elif page=='📖 Quick Lessons':lessons_page()
elif page=='📊 Progress & Profile':progress_page()
else:official()
