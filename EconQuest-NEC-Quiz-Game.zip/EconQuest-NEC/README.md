# 🧠 EconQuest — Learn economics through a quiz game

**An open-source, quiz-first learning app for students preparing for the National Economics Challenge (David Ricardo fundamentals).** Built with Python, Streamlit, Plotly, and Pandas.

> Independent educational project. Not affiliated with, sponsored by, or endorsed by the Council for Economic Education or National Economics Challenge.

## ✨ Features

- **Quiz Arena**: One question at a time with instant feedback and a worked explanation for *every* item.
- **66 original question variants** in a fixed-seed bank: 18 written questions and 48 numerical variants across CPI, GDP, unemployment, and elasticity. Change the seed to generate new numerical versions.
- **Three learning modes**: mixed practice, adaptive review (prioritizes mistakes and weak topics), and review missed questions.
- **Interactive Graph Lab**: live AD–SRAS shifts, micro supply/demand shifts, and editable GDP expenditure inputs with a bar chart and table.
- **Visual questions**: some practice questions display contextual graphs and tables.
- **Vocabulary Vault**: incorrect answers automatically save relevant economic terms. Create multiple named lists, add custom definitions, flip vocabulary cards, and remove words.
- **XP and statistics**: track accuracy and weak topics over time in your session.
- **Portable progress**: export a JSON profile and import it later to recover practice history, XP, and vocabulary lists.
- **Official NEC links**: access actual published sample exams on official platforms without copying exam question text.

## 🚀 Run on your computer

```bash
python3 -m venv .venv
source .venv/bin/activate  # Windows PowerShell: .venv\Scripts\Activate.ps1
python3 -m pip install -r requirements.txt
python3 -m streamlit run app.py
```

Open the local URL printed by Streamlit (normally `http://localhost:8501`).

## ☁️ Publish online

1. Create a **public** GitHub repository named `EconQuest-NEC`.
2. Upload the contents of this project folder (keep `app.py` and `requirements.txt` at repository root).
3. Visit [Streamlit Community Cloud](https://share.streamlit.io/), connect the repository, set entrypoint to `app.py`, and deploy.
4. Add your live demo link to the top of this README and test it from a new browser.

## 🧩 Project structure

```text
EconQuest-NEC/
├── app.py                 # Streamlit UI and game flow
├── content.py             # Lessons and 18 original base questions
├── quiz_engine.py         # 48 generated questions, review logic, scoring
├── profile.py             # Dictionary, custom lists, JSON export/import
├── visuals.py             # Plotly interactive graphs
├── economics.py           # Illustrative equilibrium math
├── requirements.txt
├── requirements-dev.txt
├── .streamlit/config.toml
└── tests/
    ├── test_economics.py
    └── test_game.py
```

## 🧠 How adaptive practice works

Each submitted answer increments the question's correct or missed count. In adaptive mode, a question receives an increased sampling weight if it has been missed, or if its topic includes other mistakes. Sampling is done without replacement *within a single round*, so you can see different questions in that round. Review-missed mode uses questions that have been missed at least once; it does **not** currently remove questions after a subsequent correct response. This is a rule-based practice algorithm, not machine learning.

Numerical item templates generate variations with a deterministic random seed. They are **not AI-generated live**, so the app runs without external API keys or costs.

## 🔒 Progress and privacy

Your profile lives in Streamlit session state while the app is running. **It is not automatically persistent**, especially after closing the page, refreshing the app, or when a cloud app restarts. To retain your vocabulary lists and scores, download your `.json` learning profile under **Progress & Profile** and upload it on your next visit. Do not share exported personal progress files publicly.

No user registration or payment information is collected.

## 📚 Official practice vs. original questions

**Every in-app question is original** and includes an explanation. Actual NEC examples are available at the original publishers' pages:

- [Official David Ricardo practice exam](https://econchallenge.unl.edu/Nebraska/Practice)
- [Council for Economic Education competitions](https://www.councilforeconed.org/competitions/)
- [MCEE economics challenge preparation](https://www.econed.org/economics-challenge/)

The actual official sample questions are **not bundled** with this repository or represented as original content. If licensing/permission is obtained for a particular exam set, it can be added with proper attribution and provenance.

## 🧪 Tests

```bash
python3 -m pip install -r requirements-dev.txt
python3 -m pytest -q
```

Tests cover equilibrium shift direction, question format, deterministic generation, category filters, missed-question selection, scoring, and portable profile validation. Automated tests are not a substitute for browser-based UX testing.

## 🔭 Future ideas

Optional difficulty ladders, timed rounds, teacher-authored question packs, authenticated cloud progress, verified licensing for official questions, and more visual models (PPF, Phillips curve, cost curves).

## ⚠️ Academic note

This project is a learning aid. Model curves and illustrative numbers are not forecasts of economic outcomes. Correct performance on practice questions does not guarantee a competition result.
