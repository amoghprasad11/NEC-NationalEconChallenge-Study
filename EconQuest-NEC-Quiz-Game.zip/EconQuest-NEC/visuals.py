"""Plotly visuals to support question-based economics learning."""
import numpy as np
import plotly.graph_objects as go
from economics import equilibrium

COLORS={'ad':'#4382de','as':'#ec9d44','green':'#20b897'}

def adas_figure(ad=0,sras=0):
    outputs=np.linspace(55,350,220)
    fig=go.Figure()
    for name,p,shift,color in [('AD (original)',160-0.4*outputs,0,COLORS['ad']),
                               ('SRAS (original)',40+0.2*outputs,0,COLORS['as'])]:
        fig.add_trace(go.Scatter(x=outputs,y=p,name=name,line=dict(color=color,dash='dot',width=2)))
    fig.add_trace(go.Scatter(x=outputs,y=160-0.4*outputs+ad,name='AD (new)',line=dict(color=COLORS['ad'],width=4)))
    fig.add_trace(go.Scatter(x=outputs,y=40+0.2*outputs-sras,name='SRAS (new)',line=dict(color=COLORS['as'],width=4)))
    original,new=equilibrium(),equilibrium(ad,sras)
    fig.add_trace(go.Scatter(x=[original.output,new.output],y=[original.price_level,new.price_level],
             mode='markers+text',text=['Before','After'],textposition=['bottom left','top right'],
             marker=dict(size=10,color=['#64748b',COLORS['green']]),name='Equilibrium'))
    fig.update_layout(xaxis_title='Real GDP (illustrative index)',yaxis_title='Overall price level (illustrative index)',
        height=385,margin=dict(l=15,r=15,t=25,b=10),legend=dict(orientation='h',y=-0.28),
        template='plotly_white')
    return fig

def market_figure(demand_shift=0,supply_shift=0):
    q=np.linspace(0,100,120)
    fig=go.Figure()
    for desc,pr,color in [('Demand',100-q+demand_shift,COLORS['ad']),
                           ('Supply',10+q-supply_shift,COLORS['as'])]:
        fig.add_trace(go.Scatter(x=q,y=pr,name=desc,line=dict(color=color,width=4)))
    fig.update_layout(xaxis_title='Quantity',yaxis_title='Price',height=350,template='plotly_white',
                      margin=dict(l=15,r=15,t=20,b=10))
    return fig

def gdp_figure(c=500,i=120,g=180,x=50,m=70):
    fig=go.Figure(go.Bar(x=['Consumption','Investment','Government','Exports','Imports'],
         y=[c,i,g,x,-m],marker_color=['#4382de','#20b897','#ec9d44','#8b6de2','#e66f71']))
    fig.update_layout(height=340,yaxis_title='Contribution to GDP',template='plotly_white',
                      margin=dict(l=15,r=15,t=15,b=10))
    return fig
