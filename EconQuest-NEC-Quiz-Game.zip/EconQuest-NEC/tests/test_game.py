import json
import pytest
from quiz_engine import all_questions,choose_questions,record_answer,TOPICS,generated_questions
from profile import new_profile,add_vocab,to_json,validate_profile

def test_questions_and_answer_bounds():
    q=all_questions()
    assert len(q)==66
    assert len({x['id'] for x in q})==len(q)
    for item in q:
        assert len(item['choices'])==4
        assert len(set(item['choices']))==4, item['id']
        assert 0<=item['answer']<4
        assert item['explanation'] and item['terms']
        assert item['topic'] in TOPICS[item['category']]

def test_generated_deterministic():
    assert generated_questions(42)==generated_questions(42)
    assert generated_questions(42)!=generated_questions(43)

def test_pick_by_category():
    chosen=choose_questions(all_questions(),8,category='Microeconomics')
    assert len(chosen)==8
    assert all(q['category']=='Microeconomics' for q in chosen)

def test_review_missed():
    q=all_questions()[0]
    history={q['id']:{'right':0,'wrong':1}}
    assert [x['id'] for x in choose_questions(all_questions(),10,'Review missed',history)]==[q['id']]
    assert choose_questions(all_questions(),10,'Review missed',{})==[]

def test_record_answer_updates_without_mutation():
    q=all_questions()[0]
    old={}
    result,ok=record_answer(old,q,q['answer'])
    assert ok and result[q['id']]['right']==1 and old=={}
    result,ok=record_answer(result,q,(q['answer']+1)%4)
    assert not ok and result[q['id']]['wrong']==1

def test_profile_roundtrip():
    p=new_profile()
    add_vocab(p,'Aggregate demand')
    add_vocab(p,'Aggregate demand')
    assert p['lists']['Missed concepts']==['Aggregate demand']
    assert validate_profile(json.loads(to_json(p)))==p

def test_profile_rejects_bad():
    with pytest.raises(ValueError):validate_profile({'version':999})
    with pytest.raises(ValueError):validate_profile({'version':1,'lists':{'x':'bad'}})
