from economics import equilibrium, directional_summary
from content import validate_question_bank, LESSONS

def test_base_equilibrium():
    result=equilibrium()
    assert result.output==200
    assert result.price_level==80

def test_ad_positive():
    assert equilibrium(ad_shift=20).output>equilibrium().output
    assert equilibrium(ad_shift=20).price_level>equilibrium().price_level

def test_ad_negative():
    assert equilibrium(ad_shift=-20).output<equilibrium().output
    assert equilibrium(ad_shift=-20).price_level<equilibrium().price_level

def test_supply_positive():
    assert equilibrium(sras_shift=20).output>equilibrium().output
    assert equilibrium(sras_shift=20).price_level<equilibrium().price_level

def test_supply_negative():
    assert equilibrium(sras_shift=-20).output<equilibrium().output
    assert equilibrium(sras_shift=-20).price_level>equilibrium().price_level

def test_questions():
    assert validate_question_bank()

def test_lessons():
    assert all(all(k in lesson for k in ['name','explanation','formula','example']) for topic in LESSONS.values() for lesson in topic)

def test_multiple_shifts_message():
    assert 'Both curves' in directional_summary(10,10)
