"""Simple, explicitly illustrative linear AD–AS model for learning curve shifts."""
from dataclasses import dataclass

@dataclass(frozen=True)
class Equilibrium:
    output: float
    price_level: float


def equilibrium(ad_shift: float = 0, sras_shift: float = 0) -> Equilibrium:
    """AD: P=160−0.4Y+ADshift; SRAS: P=40+0.2Y−SRASshift.

    Rightward AD moves upward in price-output coordinates; rightward SRAS
    moves downward. Curves are illustrative and not estimated economic data.
    """
    output = (120 + ad_shift + sras_shift) / 0.6
    price_level = 40 + 0.2 * output - sras_shift
    return Equilibrium(round(output, 2), round(price_level, 2))


def directional_summary(ad_shift: float, sras_shift: float) -> str:
    if ad_shift and sras_shift:
        return 'Both curves move. Inspect the graph: some effects depend on which shift is larger.'
    if ad_shift > 0: return 'AD shifts right: price level ↑ and real GDP ↑ in the short run.'
    if ad_shift < 0: return 'AD shifts left: price level ↓ and real GDP ↓ in the short run.'
    if sras_shift > 0: return 'SRAS shifts right: price level ↓ and real GDP ↑ in the short run.'
    if sras_shift < 0: return 'SRAS shifts left: price level ↑ and real GDP ↓ in the short run.'
    return 'Neither curve shifted. Short-run equilibrium is unchanged.'
